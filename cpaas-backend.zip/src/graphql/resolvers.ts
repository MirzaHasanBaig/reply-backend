import { User } from "../models/User"

export const resolvers = {
  Query: {
    getUser: async (_: any, { id }: { id: string }) => {
      return await User.findById(id)
    },
  },
  Mutation: {
    createUser: async (_: any, { name, email, password }: { name: string; email: string; password: string }) => {
      const user = new User({ name, email, password })
      await user.save()
      return user
    },
  },
}

