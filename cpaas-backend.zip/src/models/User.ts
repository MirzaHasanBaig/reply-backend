import mongoose from "mongoose"
import bcrypt from "bcrypt"

const userSchema = new mongoose.Schema({
  name: { type: String, required: true },
  email: { type: String, required: true, unique: true },
  password: { type: String, required: true },
  role: { type: String, enum: ["client", "editor", "support", "view"], default: "client" },
  company: { type: mongoose.Schema.Types.ObjectId, ref: "Company" },
  companyRole: { type: String, enum: ["admin", "editor", "support"] },
  googleId: String,
  microsoftId: String,
  otpSecret: String,
  authenticatorSecret: String,
  createdAt: { type: Date, default: Date.now },
  updatedAt: { type: Date, default: Date.now },
})

userSchema.pre("save", async function (next) {
  if (this.isModified("password")) {
    this.password = await bcrypt.hash(this.password, 10)
  }
  next()
})

export const User = mongoose.model("User", userSchema)

