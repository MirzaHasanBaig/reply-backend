import csv from "csv-parser"
import { createObjectCsvWriter } from "csv-writer"
import fs from "fs"

export const importCSV = (filePath: string): Promise<any[]> => {
  return new Promise((resolve, reject) => {
    const results: any[] = []
    fs.createReadStream(filePath)
      .pipe(csv())
      .on("data", (data) => results.push(data))
      .on("end", () => resolve(results))
      .on("error", (error) => reject(error))
  })
}

export const exportCSV = async (data: any[], fields: string[], filePath: string) => {
  const csvWriter = createObjectCsvWriter({
    path: filePath,
    header: fields.map((field) => ({ id: field, title: field })),
  })

  await csvWriter.writeRecords(data)
}

