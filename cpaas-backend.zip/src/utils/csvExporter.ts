import { Parser } from "json2csv"
import fs from "fs"

export const exportCSV = (data: any[], fields: string[], filePath: string) => {
  const json2csvParser = new Parser({ fields })
  const csv = json2csvParser.parse(data)

  return new Promise((resolve, reject) => {
    fs.writeFile(filePath, csv, (err) => {
      if (err) reject(err)
      else resolve(filePath)
    })
  })
}

