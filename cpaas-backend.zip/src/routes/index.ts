import { Router } from "express"
import authRoutes from "./authRoutes"
import userRoutes from "./userRoutes"
import campaignRoutes from "./campaignRoutes"
import contactRoutes from "./contactRoutes"
import chatbotRoutes from "./chatbotRoutes"
import webinarRoutes from "./webinarRoutes"
import automationRoutes from "./automationRoutes"
import productRoutes from "./productRoutes"
import orderRoutes from "./orderRoutes"
import newsletterRoutes from "./newsletterRoutes"
import integrationRoutes from "./integrationRoutes"
import { adminMiddleware } from "../middleware/auth"

const router = Router()

router.use("/auth", authRoutes)
router.use("/users", userRoutes)
router.use("/campaigns", campaignRoutes)
router.use("/contacts", contactRoutes)
router.use("/chatbots", chatbotRoutes)
router.use("/webinars", webinarRoutes)
router.use("/automations", automationRoutes)
router.use("/products", productRoutes)
router.use("/orders", orderRoutes)
router.use("/newsletters", newsletterRoutes)
router.use("/integrations", integrationRoutes)

// Admin routes
router.use("/admin", adminMiddleware, (adminRouter) => {
  adminRouter.use("/users", userRoutes)
  // Add other admin routes here
})

export default router

