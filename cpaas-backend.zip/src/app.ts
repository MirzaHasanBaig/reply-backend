import express from "express"
import cors from "cors"
import helmet from "helmet"
import compression from "compression"
import rateLimit from "express-rate-limit"
import { connectDB } from "./config/database"
import { setupRedis } from "./config/redis"
import { setupBull } from "./config/bull"
import { setupCron } from "./config/cron"
import { errorHandler } from "./middleware/errorHandler"
import { loggerMiddleware } from "./middleware/logger"
import { authMiddleware, roleMiddleware } from "./middleware/auth"
import routes from "./routes"

const app = express()

// Middleware
app.use(cors())
app.use(helmet())
app.use(compression())
app.use(express.json())
app.use(express.urlencoded({ extended: true }))
app.use(loggerMiddleware)

// Rate limiting
const limiter = rateLimit({
  windowMs: 15 * 60 * 1000, // 15 minutes
  max: 100, // limit each IP to 100 requests per windowMs
})
app.use(limiter)

// Connect to database
connectDB()

// Setup Redis
setupRedis()

// Setup Bull
setupBull()

// Setup Cron jobs
setupCron()

// Routes
app.use("/api", authMiddleware, roleMiddleware(["user", "admin"]), routes)

// Error handling middleware
app.use(errorHandler)

const PORT = process.env.PORT || 3000
app.listen(PORT, () => {
  console.log(`Server is running on port ${PORT}`)
})

export default app

