import { Newsletter } from "../models/Newsletter"
import { sendEmail } from "../utils/emailSender"
import { logger } from "../utils/logger"

export const signupNewsletter = async (email: string) => {
  try {
    const newsletter = await Newsletter.findOneAndUpdate({ email }, { email }, { upsert: true, new: true })
    logger.info(`Newsletter signup: ${email}`)
    return newsletter
  } catch (error) {
    logger.error(`Error signing up for newsletter: ${error}`)
    throw error
  }
}

export const sendNewsletter = async (subject: string, content: string) => {
  try {
    const subscribers = await Newsletter.find()
    for (const subscriber of subscribers) {
      await sendEmail(subscriber.email, subject, content)
    }
    logger.info(`Newsletter sent to ${subscribers.length} subscribers`)
  } catch (error) {
    logger.error(`Error sending newsletter: ${error}`)
    throw error
  }
}

