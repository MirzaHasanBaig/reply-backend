import { ConfidentialClientApplication } from "@azure/msal-node"
import { logger } from "../utils/logger"

const config = {
  auth: {
    clientId: process.env.AZURE_CLIENT_ID as string,
    authority: process.env.AZURE_AUTHORITY as string,
    clientSecret: process.env.AZURE_CLIENT_SECRET as string,
  },
}

const client = new ConfidentialClientApplication(config)

export const getAzureToken = async () => {
  try {
    const result = await client.acquireTokenByClientCredential({
      scopes: ["https://graph.microsoft.com/.default"],
    })
    logger.info("Azure token acquired")
    return result?.accessToken
  } catch (error) {
    logger.error(`Error acquiring Azure token: ${error}`)
    throw error
  }
}

