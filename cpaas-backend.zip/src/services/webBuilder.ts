import { Website } from "../models/Website"

export const createWebsite = async (name: string, content: any) => {
  const website = new Website({ name, content })
  await website.save()
  return website
}

export const updateWebsite = async (id: string, name: string, content: any) => {
  const website = await Website.findByIdAndUpdate(id, { name, content }, { new: true })
  return website
}

export const deleteWebsite = async (id: string) => {
  await Website.findByIdAndDelete(id)
}

