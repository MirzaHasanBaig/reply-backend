import { Chatbot } from "../models/Chatbot"

export const createChatbot = async (name: string, nodes: any[]) => {
  const chatbot = new Chatbot({ name, nodes })
  await chatbot.save()
  return chatbot
}

export const updateChatbot = async (id: string, name: string, nodes: any[]) => {
  const chatbot = await Chatbot.findByIdAndUpdate(id, { name, nodes }, { new: true })
  return chatbot
}

export const deleteChatbot = async (id: string) => {
  await Chatbot.findByIdAndDelete(id)
}

