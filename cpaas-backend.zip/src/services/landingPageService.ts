import { LandingPage } from "../models/LandingPage"
import { logger } from "../utils/logger"

export const createLandingPage = async (userId: string, pageData: any) => {
  try {
    const landingPage = new LandingPage({ ...pageData, user: userId })
    await landingPage.save()
    logger.info(`Landing page created: ${landingPage.id}`)
    return landingPage
  } catch (error) {
    logger.error(`Error creating landing page: ${error}`)
    throw error
  }
}

export const publishLandingPage = async (pageId: string) => {
  const landingPage = await LandingPage.findById(pageId)
  if (!landingPage) {
    throw new Error("Landing page not found")
  }

  landingPage.isPublished = true
  await landingPage.save()
  logger.info(`Landing page published: ${pageId}`)
}

export const trackPageView = async (pageId: string) => {
  const landingPage = await LandingPage.findById(pageId)
  if (!landingPage) {
    throw new Error("Landing page not found")
  }

  landingPage.analytics.views += 1
  await landingPage.save()
}

export const trackConversion = async (pageId: string) => {
  const landingPage = await LandingPage.findById(pageId)
  if (!landingPage) {
    throw new Error("Landing page not found")
  }

  landingPage.analytics.conversions += 1
  await landingPage.save()
}

