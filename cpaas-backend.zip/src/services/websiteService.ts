import { Website } from "../models/Website"
import { logger } from "../utils/logger"

export const createWebsite = async (userId: string, websiteData: any) => {
  try {
    const website = new Website({ ...websiteData, creator: userId })
    await website.save()
    logger.info(`Website created: ${website.id}`)
    return website
  } catch (error) {
    logger.error(`Error creating website: ${error}`)
    throw error
  }
}

export const updateWebsite = async (websiteId: string, updateData: any) => {
  try {
    const website = await Website.findByIdAndUpdate(websiteId, updateData, { new: true })
    if (!website) throw new Error("Website not found")
    logger.info(`Website updated: ${websiteId}`)
    return website
  } catch (error) {
    logger.error(`Error updating website: ${error}`)
    throw error
  }
}

export const deleteWebsite = async (websiteId: string) => {
  try {
    await Website.findByIdAndDelete(websiteId)
    logger.info(`Website deleted: ${websiteId}`)
  } catch (error) {
    logger.error(`Error deleting website: ${error}`)
    throw error
  }
}

export const getWebsites = async (filters: any = {}) => {
  try {
    const websites = await Website.find(filters)
    return websites
  } catch (error) {
    logger.error(`Error fetching websites: ${error}`)
    throw error
  }
}

