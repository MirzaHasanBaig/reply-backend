import Queue from "bull"
import { redis } from "./redis"

export const emailQueue = new Queue("email", { redis })
export const smsQueue = new Queue("sms", { redis })
export const whatsappQueue = new Queue("whatsapp", { redis })

export const setupBull = () => {
  // Setup queue processors
  emailQueue.process(async (job) => {
    // Process email jobs
  })

  smsQueue.process(async (job) => {
    // Process SMS jobs
  })

  whatsappQueue.process(async (job) => {
    // Process WhatsApp jobs
  })
}

