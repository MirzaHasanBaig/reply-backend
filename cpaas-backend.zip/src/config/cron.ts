import cron from "node-cron"

export const setupCron = () => {
  // Schedule tasks
  cron.schedule("0 0 * * *", () => {
    // Daily task
  })

  cron.schedule("0 0 * * 0", () => {
    // Weekly task
  })
}

